//
// Created by avtomato on 1/8/18.
//

#ifndef COURSERA_QUERY_H
#define COURSERA_QUERY_H

#endif //COURSERA_QUERY_H

#pragma once

#include <iostream>
#include <vector>

using namespace std;


enum class QueryType {
    NewBus,
    BusesForStop,
    StopsForBus,
    AllBuses
};

struct Query {
    QueryType type;
    string bus;
    string stop;
    vector<string> stops;
};

istream& operator >> (istream& is, Query& q);
